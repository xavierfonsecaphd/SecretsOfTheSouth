var require = meteorInstall({"imports":{"api":{"tasks.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// imports/api/tasks.js                                                                          //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
module.export({
  Tasks: () => Tasks
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 2);
const Tasks = new Mongo.Collection('tasks');

if (Meteor.isServer) {
  // This code only runs on the server
  // Only publish tasks that are public or belong to the current user
  Meteor.publish('tasks', function tasksPublication() {
    return Tasks.find({
      $or: [{
        private: {
          $ne: true
        }
      }, {
        owner: this.userId
      }]
    });
  });
}

Meteor.methods({
  'tasks.insert'(text) {
    check(text, String); // Make sure the user is logged in before inserting a task

    if (!this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    Tasks.insert({
      text,
      createdAt: new Date(),
      owner: this.userId,
      username: Meteor.users.findOne(this.userId).username
    });
  },

  'tasks.remove'(taskId) {
    check(taskId, String);
    Tasks.remove(taskId);
  },

  'tasks.setChecked'(taskId, setChecked) {
    check(taskId, String);
    check(setChecked, Boolean);
    Tasks.update(taskId, {
      $set: {
        checked: setChecked
      }
    });
  },

  'tasks.setPrivate'(taskId, setToPrivate) {
    check(taskId, String);
    check(setToPrivate, Boolean);
    const task = Tasks.findOne(taskId); // Make sure only the task owner can make a task private

    if (task.owner !== this.userId) {
      throw new Meteor.Error('not-authorized');
    }

    Tasks.update(taskId, {
      $set: {
        private: setToPrivate
      }
    });
  }

});
///////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// server/main.js                                                                                //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.watch(require("../imports/api/tasks.js"));
Meteor.startup(() => {
  // code to run on server at startup
  console.log('Server running at ...');
});
///////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFza3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIlRhc2tzIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwiY2hlY2siLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwidGFza3NQdWJsaWNhdGlvbiIsImZpbmQiLCIkb3IiLCJwcml2YXRlIiwiJG5lIiwib3duZXIiLCJ1c2VySWQiLCJtZXRob2RzIiwidGV4dCIsIlN0cmluZyIsIkVycm9yIiwiaW5zZXJ0IiwiY3JlYXRlZEF0IiwiRGF0ZSIsInVzZXJuYW1lIiwidXNlcnMiLCJmaW5kT25lIiwidGFza0lkIiwicmVtb3ZlIiwic2V0Q2hlY2tlZCIsIkJvb2xlYW4iLCJ1cGRhdGUiLCIkc2V0IiwiY2hlY2tlZCIsInNldFRvUHJpdmF0ZSIsInRhc2siLCJzdGFydHVwIiwiY29uc29sZSIsImxvZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFNBQU0sTUFBSUE7QUFBWCxDQUFkO0FBQWlDLElBQUlDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJQyxLQUFKO0FBQVVQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0UsUUFBTUQsQ0FBTixFQUFRO0FBQUNDLFlBQU1ELENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUUsS0FBSjtBQUFVUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNHLFFBQU1GLENBQU4sRUFBUTtBQUFDRSxZQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBS3BMLE1BQU1KLFFBQVEsSUFBSUssTUFBTUUsVUFBVixDQUFxQixPQUFyQixDQUFkOztBQU1QLElBQUlOLE9BQU9PLFFBQVgsRUFBcUI7QUFDbkI7QUFDQTtBQUNBUCxTQUFPUSxPQUFQLENBQWUsT0FBZixFQUF3QixTQUFTQyxnQkFBVCxHQUE0QjtBQUNsRCxXQUFPVixNQUFNVyxJQUFOLENBQVc7QUFDaEJDLFdBQUssQ0FDSDtBQUFFQyxpQkFBUztBQUFFQyxlQUFLO0FBQVA7QUFBWCxPQURHLEVBRUg7QUFBRUMsZUFBTyxLQUFLQztBQUFkLE9BRkc7QUFEVyxLQUFYLENBQVA7QUFNRCxHQVBEO0FBUUQ7O0FBRURmLE9BQU9nQixPQUFQLENBQWU7QUFFYixpQkFBZUMsSUFBZixFQUFxQjtBQUNuQlosVUFBTVksSUFBTixFQUFZQyxNQUFaLEVBRG1CLENBR25COztBQUNBLFFBQUksQ0FBRSxLQUFLSCxNQUFYLEVBQW1CO0FBQ2pCLFlBQU0sSUFBSWYsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDs7QUFFRHBCLFVBQU1xQixNQUFOLENBQWE7QUFDWEgsVUFEVztBQUVYSSxpQkFBVyxJQUFJQyxJQUFKLEVBRkE7QUFHWFIsYUFBTyxLQUFLQyxNQUhEO0FBSVhRLGdCQUFVdkIsT0FBT3dCLEtBQVAsQ0FBYUMsT0FBYixDQUFxQixLQUFLVixNQUExQixFQUFrQ1E7QUFKakMsS0FBYjtBQU1ELEdBaEJZOztBQWtCYixpQkFBZUcsTUFBZixFQUF1QjtBQUNyQnJCLFVBQU1xQixNQUFOLEVBQWNSLE1BQWQ7QUFFQW5CLFVBQU00QixNQUFOLENBQWFELE1BQWI7QUFDRCxHQXRCWTs7QUF3QmIscUJBQW1CQSxNQUFuQixFQUEyQkUsVUFBM0IsRUFBdUM7QUFDckN2QixVQUFNcUIsTUFBTixFQUFjUixNQUFkO0FBQ0FiLFVBQU11QixVQUFOLEVBQWtCQyxPQUFsQjtBQUVBOUIsVUFBTStCLE1BQU4sQ0FBYUosTUFBYixFQUFxQjtBQUFFSyxZQUFNO0FBQUVDLGlCQUFTSjtBQUFYO0FBQVIsS0FBckI7QUFDRCxHQTdCWTs7QUErQmIscUJBQW1CRixNQUFuQixFQUEyQk8sWUFBM0IsRUFBeUM7QUFDdkM1QixVQUFNcUIsTUFBTixFQUFjUixNQUFkO0FBQ0FiLFVBQU00QixZQUFOLEVBQW9CSixPQUFwQjtBQUVBLFVBQU1LLE9BQU9uQyxNQUFNMEIsT0FBTixDQUFjQyxNQUFkLENBQWIsQ0FKdUMsQ0FNdkM7O0FBQ0EsUUFBSVEsS0FBS3BCLEtBQUwsS0FBZSxLQUFLQyxNQUF4QixFQUFnQztBQUM5QixZQUFNLElBQUlmLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7O0FBRURwQixVQUFNK0IsTUFBTixDQUFhSixNQUFiLEVBQXFCO0FBQUVLLFlBQU07QUFBRW5CLGlCQUFTcUI7QUFBWDtBQUFSLEtBQXJCO0FBRUQ7O0FBNUNZLENBQWYsRTs7Ozs7Ozs7Ozs7QUN4QkEsSUFBSWpDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRE4sT0FBT0ksS0FBUCxDQUFhQyxRQUFRLHlCQUFSLENBQWI7QUFHMUVGLE9BQU9tQyxPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBQyxVQUFRQyxHQUFSLENBQVksdUJBQVo7QUFDRCxDQUhELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuXG4vLyB0aGUgJ3Rhc2tzJyBpcyB0aGUgbW9uZ29EQiBpbiB0aGUgc2VydmVyXG5leHBvcnQgY29uc3QgVGFza3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndGFza3MnKTtcblxuXG5cbiBcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAvLyBUaGlzIGNvZGUgb25seSBydW5zIG9uIHRoZSBzZXJ2ZXJcbiAgLy8gT25seSBwdWJsaXNoIHRhc2tzIHRoYXQgYXJlIHB1YmxpYyBvciBiZWxvbmcgdG8gdGhlIGN1cnJlbnQgdXNlclxuICBNZXRlb3IucHVibGlzaCgndGFza3MnLCBmdW5jdGlvbiB0YXNrc1B1YmxpY2F0aW9uKCkge1xuICAgIHJldHVybiBUYXNrcy5maW5kKHtcbiAgICAgICRvcjogW1xuICAgICAgICB7IHByaXZhdGU6IHsgJG5lOiB0cnVlIH0gfSxcbiAgICAgICAgeyBvd25lcjogdGhpcy51c2VySWQgfSxcbiAgICAgIF0sXG4gICAgfSk7XG4gIH0pO1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG5cdFxuICAndGFza3MuaW5zZXJ0Jyh0ZXh0KSB7XG4gICAgY2hlY2sodGV4dCwgU3RyaW5nKTtcblxuICAgIC8vIE1ha2Ugc3VyZSB0aGUgdXNlciBpcyBsb2dnZWQgaW4gYmVmb3JlIGluc2VydGluZyBhIHRhc2tcbiAgICBpZiAoISB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKTtcbiAgICB9XG5cbiAgICBUYXNrcy5pbnNlcnQoe1xuICAgICAgdGV4dCxcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgIG93bmVyOiB0aGlzLnVzZXJJZCxcbiAgICAgIHVzZXJuYW1lOiBNZXRlb3IudXNlcnMuZmluZE9uZSh0aGlzLnVzZXJJZCkudXNlcm5hbWUsXG4gICAgfSk7XG4gIH0sXG5cbiAgJ3Rhc2tzLnJlbW92ZScodGFza0lkKSB7XG4gICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuIFxuICAgIFRhc2tzLnJlbW92ZSh0YXNrSWQpO1xuICB9LFxuXG4gICd0YXNrcy5zZXRDaGVja2VkJyh0YXNrSWQsIHNldENoZWNrZWQpIHtcbiAgICBjaGVjayh0YXNrSWQsIFN0cmluZyk7XG4gICAgY2hlY2soc2V0Q2hlY2tlZCwgQm9vbGVhbik7XG5cbiAgICBUYXNrcy51cGRhdGUodGFza0lkLCB7ICRzZXQ6IHsgY2hlY2tlZDogc2V0Q2hlY2tlZCB9IH0pO1xuICB9LFxuICBcbiAgJ3Rhc2tzLnNldFByaXZhdGUnKHRhc2tJZCwgc2V0VG9Qcml2YXRlKSB7XG4gICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuICAgIGNoZWNrKHNldFRvUHJpdmF0ZSwgQm9vbGVhbik7XG5cbiAgICBjb25zdCB0YXNrID0gVGFza3MuZmluZE9uZSh0YXNrSWQpO1xuIFxuICAgIC8vIE1ha2Ugc3VyZSBvbmx5IHRoZSB0YXNrIG93bmVyIGNhbiBtYWtlIGEgdGFzayBwcml2YXRlXG4gICAgaWYgKHRhc2sub3duZXIgIT09IHRoaXMudXNlcklkKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgIH1cblxuICAgIFRhc2tzLnVwZGF0ZSh0YXNrSWQsIHsgJHNldDogeyBwcml2YXRlOiBzZXRUb1ByaXZhdGUgfSB9KTtcblxuICB9LFxuXG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvdGFza3MuanMnO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG4gIGNvbnNvbGUubG9nKCdTZXJ2ZXIgcnVubmluZyBhdCAuLi4nKTtcbn0pO1xuIl19
